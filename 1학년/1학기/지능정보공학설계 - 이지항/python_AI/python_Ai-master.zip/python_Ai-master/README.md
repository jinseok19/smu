# python_Ai
지능정보공학설계 - 이지항 교수님

pandas 라이브러리 부분

