import pandas as pd
acci = pd.read_csv('acci.csv', encoding='cp949')
print(acci.head())