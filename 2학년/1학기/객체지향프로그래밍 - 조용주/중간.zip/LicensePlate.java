/* 202210829 김진석  정찬의 검*/
public class LicensePlate {
    String number;
    boolean parseError;

    int firstNum;
    int secondNum;
    char hangul;
    char[] hangulArray;

    LicensePlate(char[] hangulArr){
        this.number = null;
        this.parseError = false;
        this.hangulArray = new char[hangulArr.length];

    }

    boolean getParseError(){
        parseError = parseNumber();
        if(!parseError){
            return true;
        }
        else{
            return false;
        }


    }
    void setNumber(String num){
        number = num.substring(0,3);

       ;
    }
    void printInfo(){
       if(parseNumber()){
           System.out.printf();

        }
    }
    boolean parseNumber(){
        firstNum = getFirstNumber();
        if(firstNum>=100 && firstNum < 700) {
            System.out.printf("승용차");
            return true;
        } else if (firstNum>700 && firstNum <800) {
            System.out.printf("승합차");
            return true;

        } else if (firstNum > 800 && firstNum <979) {
            System.out.printf("화물차");
            return true;

        } else if (firstNum > 980 && firstNum<998) {
            System.out.printf("특수차");
            return true;

        } else if (firstNum >998 && firstNum<999) {
            System.out.printf("긴급자동차");
            return true;

        }else{
        return false;
    }}
    int getSecondNumber(int idx){
        number = hangulArray.toString().charAt(idx);


        secondNum = Integer.parseInt(number);



    }
    int getFirstNumber(){
        number=hangulArray.toString().substring(0,3);
        firstNum = Integer.parseInt(number);
        if(NumString.isDigit(number)){
            firstNum = Integer.parseInt(number);
        }else if(firstNum<100){
            System.out.printf("오류 : 앞번호가 100 미만 입니다");
            return -1;
        }else{
            System.out.printf("오류: 앞번호가 숫자가 아닙니다");
            return -1;
        }
        return firstNum;
    }
}
