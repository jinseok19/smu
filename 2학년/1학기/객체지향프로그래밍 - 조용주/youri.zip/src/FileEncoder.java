import java.io.*;
import java.nio.file.NoSuchFileException;

public class FileEncoder {
    private CircularArray array;
    private RandomUtil ru;

    public FileEncoder(CircularArray array) {
        this.array = array;
    }

    // 4.1
    public String encodeString(String s) {
        array.reset();
        if (s.length() <= 0) {
            return null;
        }
        else {
            // 나머지 코드 작성

            for (String array_index : s.split("['' \t \n]")){

                if(array_index.equals("['' \t \n]")){
                    array.add(array_index);
                    array.next();
                }

                else{

                }
            }
            ru = new RandomUtil(s.length());
           array = ru.randIntInRange(array.minv, array.maxv);

        }
    }

    // 4.2
    public boolean encodeFile(String filename, String encfilename) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line = br.readLine();
            // 중간 코드 작성
            filename = encodeString(line);

            br.close();
            return true;
        }
        // 파일 없음 예외 처리 코드 작성
        catch (NoSuchFileException e){
            System.out.printf("%s 파일이 없습니다\n", filename);
        }
        catch (Exception e) {
            System.out.printf("%s 파일을 암호화할 때 오류 발생\n", filename);
        }
        return false;
    }

    // 4.3
    public String decodeString(String s) {
        array.reset();
        if (s.length() <= 0) {
            return null;
        }
        else {
            // 나머지 코드 작성
            for(String s1 : s.split("['' \n \t]")){
                
            }

        }
    }

    // 4.4
    public boolean decodeFile(String filename, String decfilename) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line = br.readLine();
            // 중간 코드 작성
            filename=decodeString(line);
            br.close();
            return true;
        }
        // 파일 없음 예외 처리 코드 작성
        catch (NoSuchFileException e){
            System.out.printf("%s 파일이 없습니다\n", filename);
        }
        catch (Exception e) {
            System.out.printf("%s 파일을 복호화할 때 오류 발생\n", filename);
        }
        return false;
    }
}
