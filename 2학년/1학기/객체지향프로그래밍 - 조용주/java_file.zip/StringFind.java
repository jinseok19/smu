import java.util.Scanner;

public class StringFind {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = "In bland lacus ac sapien dictum, elementum " +
                "fringe without varius. Vestibulum consequence " +
                "metus at felis porttitor, the neck rhoncus " +
                "consectetur. Non metus feline vehicle integer " +
                "eleifend, in bland rhesus ullamcorper. Phasellus " +
                "mauris nisi, facilities and quam placerat, leave " +
                "venetian diameter. Presented in erased audio. Phasellus " +
                "its with efficiency sem. And whom my venenatis, " +
                "feugiat just eu, rhoncus velit. Suspended " +
                "iaculis tempus tree. Integer mauris neque, " +
                "possess with me at, a little facilisis nibh. Crass " +
                "well mixed lorem. Aliquam suspects, nisl id " +
                "condimentum condimentum, purus magna maximus without, " +
                "vitae vehicula diam nisi ac enim.";

        System.out.print("Enter 5 characters: ");
        char[] characters = new char[5];
        for (int i = 0; i < 5; i++) {
            characters[i] = scanner.next().charAt(0);
        }

        for (char ch : characters) {
            int frequency = 0;
            for (int i = 0; i < input.length(); i++) {
                if (ch == input.charAt(i)) {
                    frequency++;
                }
            }
            System.out.println(ch + ":" + frequency);
        }
    }
}