import java.util.Scanner;

public class StringSplit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String sentence = "In bland lacus ac sapien dictum, elementum " +
                "fringe without varius. Vestibulum consequence " +
                "metus at felis porttitor, the neck rhoncus " +
                "consectetur. Non metus feline vehicle integer " +
                "eleifend, in bland rhesus ullamcorper. Phasellus " +
                "mauris nisi, facilities and quam placerat, leave " +
                "venetian diameter. Presented in erased audio. Phasellus " +
                "its with efficiency sem. And whom my venenatis, " +
                "feugiat just eu, rhoncus velit. Suspended " +
                "iaculis tempus tree. Integer mauris neque, " +
                "possess with me at, a little facilisis nibh. Crass " +
                "well mixed lorem. Aliquam suspects, nisl id " +
                "condimentum condimentum, purus magna maximus without, " +
                "vitae vehicula diam nisi ac enim.";

        String[] words = sentence.split(" ");
        String[] inputChars = new String[5];
        System.out.print("Enter 5 characters: ");
        for (int i = 0; i < 5; i++) {
            inputChars[i] = scanner.next();
        }
        for (String word : words) {
            for (String ch : inputChars) {
                if (word.contains(ch)) {
                    System.out.println(word);
                    break;
                }
            }
        }
    }
}