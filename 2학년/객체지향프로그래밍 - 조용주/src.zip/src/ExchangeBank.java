public class ExchangeBank {
    int count;
    IExchangeRate[] rate;


    public ExchangeBank() {
        count = 0;
        rate = new IExchangeRate[5];
    }

    public void add(String name, double rate, String monetaryName) {
        if (count < 5) {
            this.rate[count] = new IExchangeRate(name, rate, monetaryName);
        } else {
            IExchangeRate[] newRate = new IExchangeRate[count + 1];
            for (int i = 0; i < count; i++) {
                newRate[i] = this.rate[i];
            }
            newRate[count] = new IExchangeRate(name, rate, monetaryName);
            this.rate = newRate;
        }
        count++;
    }

    public double exchange(double amount) {
        IExchangeRate[] name = new IExchangeRate[count];
        for (IExchangeRate name_1 : name) {
            if (equals(name_1)) {
                return this.exchange(amount);
            }
        }
        // If the currency is not found, return -1 to indicate an error
        return -1;
    }
}
