class IExchangeRate extends ExchangeBank {
    String name;
    double rate;
    String monetaryName;

    public IExchangeRate(String name, double rate, String monetaryName) {
        super(); // call the constructor of the parent class
        this.name = name;
        this.rate = rate;
        this.monetaryName = monetaryName;
    }

    public double exchange(double won) {
        return super.exchange(won) * rate; // call the exchange method of the parent class
    }

    public String getName() {
        return name;
    }

    public double getRate() {
        return rate;
    }

    public String getMonetaryName() {
        return monetaryName;
    }
}


public class Main {

    public static void main(String[] args) {
//        String[] countries = { "미국", "중국", "영국", "유로", "스위스" };
//        double[] rate = { 1335.00, 192.97, 1668.42, 1473.64, 1502.70 };
//        String[] currencyNames = { "달러", "위안", "파운드", "유로", "프랑" };

        String[] countries = { "미국", "중국", "영국", "유로", "스위스", "캐나다", "홍콩" };
        double[] rate = { 1335.00, 192.97, 1668.42, 1473.64, 1502.70, 978.95, 170.06 };
        String[] currencyNames = { "달러", "위안", "파운드", "유로", "프랑", "달러", "달러" };
        ExchangeBank bank = new ExchangeBank();
        for (int i = 0; i < countries.length; i++) {
            bank.add(countries[i], rate[i], currencyNames[i]);
        }
        bank.exchange(100000);// 10만원을 환전할 때의 금액을 나라별로 출력
        // loop through each country and print out the exchanged amount for 100000 won
        for (int i = 0; i < countries.length; i++) {
            IExchangeRate exchangeRate = new IExchangeRate(countries[i], rate[i], currencyNames[i]);
            double exchangedAmount = exchangeRate.exchange(100000);
            System.out.printf("%s에서 환전한 금액: %.2f %s\n", exchangeRate.getName(), exchangedAmount, exchangeRate.getMonetaryName());
        }

    }
}
