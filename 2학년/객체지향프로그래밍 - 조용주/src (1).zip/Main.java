import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("미국: 1000.00 달러 --> 영국: 88.35 파운드\n");
        System.out.print("환전하 통화 국가를 입력하세요: ");
        String from_Nation = sc.next();

        System.out.print("환전 대상 통화 국가를 입력하세요: ");
        String to_Nation = sc.next();

        System.out.print("환전 금액을 입력하세요: ");
        double price = sc.nextDouble();
        ExchangeRate er1 = new ExchangeRate("미국",1335.00,"달러");
        ExchangeRate er2 = new ExchangeRate("중국",192.97,"위안");
        ExchangeRate er3 = new ExchangeRate("영국",1668.42,"파운드");
        ExchangeRate er4 = new ExchangeRate("유로",1473.64,"유로");
        ExchangeRate er5 = new ExchangeRate("스위스",1502.70,"프랑");
        ExchangeRate er6 = new ExchangeRate("캐나다",978.95,"달러");
        ExchangeRate er7 = new ExchangeRate("홍콩",170.06,"달러");
        ExchangeBank eb = new ExchangeBank();
        eb.add(er1.getCountryName(),er1.getExchangeRate(),er1.getCurrencyUnit());
        eb.add(er2.getCountryName(),er2.getExchangeRate(),er2.getCurrencyUnit());
        eb.add(er3.getCountryName(),er3.getExchangeRate(),er3.getCurrencyUnit());
        eb.add(er4.getCountryName(),er4.getExchangeRate(),er4.getCurrencyUnit());
        eb.add(er5.getCountryName(),er5.getExchangeRate(),er5.getCurrencyUnit());
        eb.add(er6.getCountryName(),er6.getExchangeRate(),er6.getCurrencyUnit());
        eb.add(er7.getCountryName(),er7.getExchangeRate(),er7.getCurrencyUnit());


        double price2 =eb.exchange(price,from_Nation,to_Nation);
        ExchangeRate from_Nation_key = eb.findExchangeRate(from_Nation);
        ExchangeRate to_Nation_key = eb.findExchangeRate(to_Nation);






        System.out.printf("%s: %.2f %s --> %s: %.2f %s",from_Nation, price,from_Nation_key, to_Nation, price2, to_Nation_key);


    }
}